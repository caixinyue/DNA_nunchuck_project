function makeFolders(binSize)
numOfFolders=360/binSize;

if exist('FakeNunchuckImages')==7
    %disp("True")
    rmdir FakeNunchuckImages s
end
mkdir FakeNunchuckImages %makes inital folder

for i=1:numOfFolders
    angle=(i-1)*binSize+(binSize/2)-180; %so that folder name is in the middle of the bin
    %disp(angle)
    folderData=['FakeNunchuckImages/' num2str(angle)]; %path of new folder with name
    mkdir(folderData)
end
end