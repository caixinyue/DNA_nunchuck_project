function out=noise(image)

%next loop adds a random value (20-30) to each pixel to simulate noise
noiseLevel=randi(20,'uint8')+20;
noiseBaseline=randi(noiseLevel/2,'uint8')+noiseLevel/3;
%noiseBaseline=noiseLevel/3
for i=1:200
    for j=1:200
        %image(i,j)=image(i,j)+randi(40,'uint8')+uint8(40);
        image(i,j)=image(i,j)+randi(noiseLevel,'uint8')+uint8(noiseBaseline);
    end 
end

%next loop will increase each pixel to simulate differences in image
%brightness
brightnessIncrease=uint8(40*rand); %random amount that each pixel will be increased by
for i=1:200
    for j=1:200
        image(i,j)=image(i,j)+brightnessIncrease;
    end 
end
out=image;
end