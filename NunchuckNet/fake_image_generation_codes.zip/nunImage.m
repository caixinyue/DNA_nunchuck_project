function out=nunImage(nunchuckAngle)
image=zeros(200,'uint8'); %blank canavas for 8bit image 

%nunchuckAngle=180*rand

[image,center]=nunchuck(image,nunchuckAngle); %creates a nunchuck on the image

image=backTube(image,center);

image=diffus(image); %applies diffusion to image in order to make it less jagged

image=noise(image); %adds noise to image

image=reformatImages(image);

out=image;

end