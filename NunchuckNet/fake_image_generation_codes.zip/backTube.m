function out=backTube(image,nunCenter) %creates a nunchuch in the image/

luck=0;
num=0;
limit=0.9; %initial threashold to determine whether arm will be drawn
if rand<limit
    luck=1;
end

while luck==1

    if rand<limit %chance that a tube will be drawn
        num=num+1;
        %center=[79,79];
        luck=1;
        center=[round(200*rand),round(200*rand)]; %randomized center
        while center(1)<120 && center(1)>80
            center(1)=round(200*rand); %randomized center
        end
        while center(2)<120 && center(2)>80
            center(2)=round(200*rand); %randomized center
        end
        angleArm=findAngle(center,nunCenter)-350*rand-5;
        %image(center(2)-1:center(2)+1,center(1)-1:center(1)+1)=uint8(255);
        brightness=100*rand+30;
        size=rand*15; %(originally 25)
        image=arm(image,angleArm,brightness,size,center);
    else
        luck=0;

    end
    limit=limit/2;
end
%image(80:120,80:120)=uint8(100);
num;
out=image;

end