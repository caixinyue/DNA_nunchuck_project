function out=diffus(P)
%solves the 2D diffusion equation to spread out the nunchuck
Nt=round(15*rand+15); %number of time steps (random with min of 15)
dt=0.1; %time step size-arbitrary units
D=1; %diffusion coefficient
dx=1; %step size

P=im2double(P); %converts imnage to double in order to make the calculations

PNew=P; %douplicates image

for k=1:Nt %time loop
    for i=2:199 %space loops
        for j=2:199
            %if(ismember([j i],dots ,'rows')==1)
             %   continue
            %end
            PNew(i,j)=double(P(i,j))+(D*dt)/(dx^2)*(P(i+1,j)+P(i-1,j)+P(i,j+1)+P(i,j-1)-4*P(i,j));
            %finite difference method for diffusion equation
        end
    end
    P=PNew; %passes new values of image for next loop
end

P=im2uint8(P); %converts image back to 8bit

out=P;
end 