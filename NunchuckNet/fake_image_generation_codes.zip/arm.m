function out=arm(image,angleInitial,brightness,size,center) %Amber's arm function

point=[0,0];%because we must start random walk from the center before we perform the rotation
Length=70*rand+size; %size of arm-depending on input and random variable
angle=angleInitial;%initial angle of the arm-input

%from Amber's filament simulation program
n_steps=round(Length)-1;%number of pixels
sigma_i=3.7;%the sigma of the Gaussian distribution from which we draw bend angle of each step

theta_i=normrnd(0,sigma_i,[1,n_steps]);
theta_i(1)=0;

running_sum=cumsum(theta_i);%the cumulative sum of angles for each filament
x=zeros(1,n_steps);%make empty arrays for storing x and y coordinates for random walks
y=zeros(1,n_steps);

%in this for-loop, fill x and y arrays using the simulated angles
for i=1:n_steps
    if i==1
        x=point(1)+cosd(running_sum(i));
        y=point(2)+sind(running_sum(i));
    else
        x(i)=x(i-1)+cosd(running_sum(i));
        y(i)=y(i-1)+sind(running_sum(i));
    end
end

%smooth the x-y curve.
for counter=1:30
    x=smooth(x);y=smooth(y);
end

if length(x)<8%for "backtubes", Length could be very short, so we don't need to do this first rotation to "correct"
    R = [cosd(angle) -sind(angle); sind(angle) cosd(angle)];%rotation matrix
    rotated = (R*[x,y]')';

    %translate the filament so it starts at the desired point.
    x=rotated(:,1)+center(1);
    y=rotated(:,2)+center(2);
else
    %now measure the inital angle
    for i=1:3%look at three vectors each of Length 2 (or 3, between 3 neighboring dots)
        vector=[x(i+4)-x(i+2),y(i+4)-y(i+2)];
        initial_angle(i)=atand(vector(2)/vector(1));
    end
    off_angle=mean(initial_angle);%calculate the inital angle that the filament is off by
    R = [cosd(-off_angle) -sind(-off_angle); sind(-off_angle) cosd(-off_angle)];%rotation matrix so the filament is at 0 degrees
    rotated = (R*[x,y]')';

    %rotate to achieve the desired orientation. Note the handedness.
    R = [cosd(angle) -sind(angle); sind(angle) cosd(angle)];%rotation matrix
    rotated_again = (R*rotated')';

    %translate the filament so it starts at the desired point.
    x=rotated_again(:,1)+center(1);
    y=rotated_again(:,2)+center(2);
end

for i=1:n_steps 
    if i==1 %does not mark first point to create the characteristic void in the middle of the nunchuck
        continue
    end
    if round(x(i))-1<1 || round(x(i))+1>200 || round(y(i))-1<1 || round(y(i))+1>200
        break
    end
    image(round(y(i))-1:round(y(i))+1,round(x(i))-1:round(x(i))+1)=uint8(brightness);%marks a 2x2 area at next point with input brightness
end
out=image;
end