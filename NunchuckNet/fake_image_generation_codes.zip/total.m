clc
close

tic


N=10; %number of images per angle that will be made
binSize=5 %angle bin size
numOfBins=360/binSize %number of angles that 180 will be split into

makeFolders(binSize) %makes folders with given bin size

for i=1:numOfBins%numOfAngles
    parfor j=1:N
    angle=(i-1)*binSize+(binSize/2)+binSize*rand-binSize/2-180;
    image=nunImage(angle);
    savePath=strcat('FakeNunchuckImages/',num2str(-1*((i-1)*binSize+(binSize/2)-180)),'/',num2str(j),')',num2str(-angle),'.tif'); %path to where the image will be saved
    imwrite(image,savePath); %writes image to right folder
    end
    disp(strcat(num2str((i/numOfBins)*100),"% Completed"))
end

runTime=toc;

strcat(num2str(N*numOfBins),' images in: ',num2str(toc/60),' mins')