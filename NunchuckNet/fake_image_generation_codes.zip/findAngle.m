function out=findAngle(new,old)

out=acosd(dot(new-old,[1,0])/(norm(new-old)*norm([1,0])))+180;
if(new(2)<100)
    out=360-out;
end

end